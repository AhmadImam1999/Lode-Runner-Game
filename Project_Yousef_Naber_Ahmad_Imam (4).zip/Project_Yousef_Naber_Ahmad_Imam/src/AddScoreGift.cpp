#include "AddScoreGift.h"
#include "Player.h"

AddScoreGift::~AddScoreGift()
{
}

void AddScoreGift::collideWith(GameObject& other)
{
	other.collideWith(*this);
}

void AddScoreGift::collideWith(Player& other)
{
	m_isDead = true;                           //to earase from vector 
	other.collideWith(*this);
}
void AddScoreGift::collideWith(Enemy& other)
{

}

void AddScoreGift::collideWith(Wall& other)
{

}

void AddScoreGift::collideWith(Money& other)
{

}

void AddScoreGift::collideWith(Rod& other)
{

}
void AddScoreGift::collideWith(Ladder& other)
{

}
void AddScoreGift::collideWith(AddLifeGift& other)
{

}
void AddScoreGift::collideWith(AddScoreGift& other)
{

}
void AddScoreGift::collideWith(AddTimeGift& other)
{

}
void AddScoreGift::collideWith(AddEnemyGift& other)
{

}
void AddScoreGift::collideWith(Gift& other)
{
	other.collideWith(*this);
}
#include "Gift.h"
#include "Player.h"


Gift::~Gift()
{
}

char Gift::c()
{
	return '+';
}


#include "Player.h"
#include <iostream>

using std::cout;
using std::endl;


int Player::m_level=1;

Player::Player()
{

}

Player::~Player()
{

}


Player::Player(const sf::Texture& texture, const sf::Vector2f& pos, const float size, const int& life, const int& score, const int& money)
	:SelfMovment(texture, pos, size), m_score(score), m_life(life), m_moneyCounter(money)
{

	m_shape.setTexture(&texture);
	m_shape.setScale(1,1);
	m_shape.setSize(sf::Vector2f(size, size));
	m_shape.setPosition(pos);
	m_inishialPositions = pos;
}

Vector2f Player::setDirection(sf::Vector2f& direction, float time ,int D)
{
	int can_move = D;

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)&& (can_move==0||can_move==1))
	{
		
			m_shape.setScale(1, 1);
			return 	{ 0, -m_movespeed * time };
		
		
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)&&(can_move==0||can_move==2))
	{
		m_shape.setScale(1, 1);
		
		return 	{ 0,m_movespeed * time };

	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
		
		
		
	{
		m_shape.setScale(-1, 1);
		m_shape.setRotation(0);
		return 	{ -m_movespeed * time, 0 };

	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
	{
		m_shape.setScale(1, 1);
		m_shape.setRotation(360);
		return 	{ m_movespeed * time, 0 };

	}
	return { 0,0 };
}

int Player::getLife() const
{
	return m_life;
}

int Player::getScore() const
{
	return m_score;
}

int Player::getMoney() const
{
	return m_moneyCounter;
}

sf::Vector2f Player::getDirection() const
{
	return m_direction;
}

bool Player::isEnemyColide() const
{
	return m_isdeadEnemyColision;
}
bool Player::addEnemy()const
{
	return add_Enemy;
}



void Player::decreaselife()
{
	m_life--;


}
int  Player::increasLevel()
{
	return ++m_level;
}

void Player::setLife(int currentlife)
{
	m_life = currentlife;
}


void Player::setMoney(int currentMoney)
{
	m_moneyCounter = currentMoney;
}

void Player::Addscore(int scoreToAdd)
{
	m_score += scoreToAdd;
}

void Player::inishialScore()
{
	m_score = 0;
}

void Player::collideWith(GameObject& other)
{
	other.collideWith(*this);
}

void Player::collideWith(Player& other)
{

}
void Player::collideWith(Gift& other)
{

}
void Player::collideWith(Rod& other)
{
	add_Time = false;
	add_Enemy = false;
	dig = false;
}
void Player::collideWith(Ladder& other)
{
	add_Time = false;
	add_Enemy = false;
	dig = false;
}

void Player::collideWith(Enemy& other)
{
	add_Time = false;
	add_Enemy = false;
	m_isdeadEnemyColision = true;     //reson of death
	m_isDead = true;   //is deat
	dig = false;
}

void Player::collideWith(Wall& other)
{
	dig = true;
	add_Time = false;
	add_Enemy = false;
	stop();

}

void Player::collideWith(Money& other)
{
	dig = false;
	m_soundefect.setBuffer(Resources::instance().getEATMoneytune());
	m_soundefect.play();
	add_Time = false;
	add_Enemy = false;
	m_score +=2*m_level;
	m_moneyCounter--;
	dig = false;
}
void Player::collideWith(AddLifeGift& other)
{

	m_soundefect.setBuffer(Resources::instance().getGIFTCOLLISONtune());
	m_soundefect.play();
	add_Time = false;
	add_Enemy = false;
	m_life += 1;
	dig = false;

}
void Player::collideWith(AddScoreGift& other)
{
	m_soundefect.setBuffer(Resources::instance().getGIFTCOLLISONtune());
	m_soundefect.play();
	m_score += 10;
	add_Time = false;
	add_Enemy = false;
	dig = false;

}
void Player::collideWith(AddTimeGift& other)
{
	m_soundefect.setBuffer(Resources::instance().getGIFTCOLLISONtune());
	m_soundefect.play();
	add_Time = true;
	add_Enemy = false;
	dig = false;

}
void Player::collideWith(AddEnemyGift& other)
{
	m_soundefect.setBuffer(Resources::instance().getGIFTCOLLISONtune());
	m_soundefect.play();
	add_Time = false;
	add_Enemy = true;
	dig = false;
}

bool Player::addTime()const
{
	return add_Time;
}
bool Player::Dig()const
{
	return dig;
}

const Vector2f& Player :: getposition() const
{
	return m_shape.getPosition();
}
void Player ::setposition(Vector2f pos)
{
	m_shape.setPosition(pos);
}
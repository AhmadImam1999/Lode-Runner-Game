#include "Resources.h"



Resources::Resources()
{
	loadresources();
}

Resources::~Resources()
{
}

Resources& Resources::instance()
{
	static Resources inst;
	return inst;
}


void Resources::loadresources()
{
	loadtextures();
	loadsound();
	loadfont();
}

void Resources::loadsound()
{
	int NUM_OF_SOUNDS = 11;

	m_soundefects.resize(NUM_OF_SOUNDS);

	m_soundefects[GameOver_S].loadFromFile("GAME_OVER.wav");
	m_soundefects[EatMoney_S].loadFromFile("EAT_MONEY.wav");
	m_soundefects[GameMusic_S].loadFromFile("GAME_MUSIC.ogg");
	m_soundefects[MenuMusic_S].loadFromFile("menumusic.ogg");
	m_soundefects[NextLevel_S].loadFromFile("NEXT_LEVEL.wav");
	m_soundefects[GiftColide_S].loadFromFile("GIFT_COLIDE.wav");
	m_soundefects[Win_S].loadFromFile("WIN.wav");
	m_soundefects[ResetLevel_S].loadFromFile("RESET_LEVEL.wav");
	m_soundefects[Fall_S].loadFromFile("FALL.wav");
	m_soundefects[Dig_S].loadFromFile("DIG.wav");

}

void Resources::loadtextures()
{


	int NUM_OF_PICTURES = 21;

	m_textures.resize(NUM_OF_PICTURES);

	m_textures[PLAYER_P].loadFromFile("PLAYER.png");
	m_textures[ENEMY1_P].loadFromFile("ENEMY1.png");
	m_textures[ENEMY2_P].loadFromFile("ENEMY2.png");
	m_textures[ENEMY3_P].loadFromFile("ENEMY3.png");
	m_textures[GIFT_P].loadFromFile("GIFT.png");
	m_textures[GIFT2_P].loadFromFile("GIFT2.png");
	m_textures[GIFT3_P].loadFromFile("GIFT3.png");
	m_textures[GIFT4_P].loadFromFile("GIFT4.png");
	m_textures[HELP_P].loadFromFile("HELP.png");
	m_textures[MONEY_P].loadFromFile("MONEY.png");
	m_textures[WALL_P].loadFromFile("WALL.png");
	m_textures[ROD_P].loadFromFile("ROD.png");
	m_textures[LADDER_P].loadFromFile("LADDER.png");
	m_textures[BACKGROUND_P].loadFromFile("BACKGROUND.png");
	m_textures[MENU_P].loadFromFile("MENU.png");
	m_textures[GAMEOVER_P].loadFromFile("GAMEOVER.png");
	m_textures[WIN_P].loadFromFile("WIN.png");
}

void Resources::loadfont()
{
	if (!m_font.loadFromFile("font.ttf"))	// if font couldn't be loaded
	{
		perror("cant load font");
		exit(EXIT_FAILURE);
	}
}



const Font& Resources::getfont() const
{
	return m_font;
}

const Texture& Resources::getBackround() const
{
	return m_textures[BACKGROUND_P];
}

const Texture& Resources::getMenu() const
{
	return m_textures[MENU_P];
}

const Texture& Resources::getPlayer() const
{
	return m_textures[PLAYER_P];
}

const Texture& Resources::getEnemy1() const
{
	return m_textures[ENEMY1_P];
}

const Texture& Resources::getEnemy2() const
{

	return m_textures[ENEMY2_P];
}
const Texture& Resources::getEnemy3() const
{

	return m_textures[ENEMY3_P];
}

const Texture& Resources::getWall() const
{

	return m_textures[WALL_P];
}

const Texture& Resources::getGift() const
{
	return m_textures[GIFT_P];
}
const Texture& Resources::getGift2() const
{
	return m_textures[GIFT2_P];
}
const Texture& Resources::getGift3() const
{
	return m_textures[GIFT3_P];
}
const Texture& Resources::getGift4() const
{
	return m_textures[GIFT4_P];
}

const Texture& Resources::getMoney() const
{
	return m_textures[MONEY_P];
}

const Texture& Resources::getRod() const
{
	return m_textures[ROD_P];
}
const Texture& Resources::getLadder() const
{
	return m_textures[LADDER_P];
}
const Texture& Resources::getHelp() const
{
	return m_textures[HELP_P];
}

const Texture& Resources::getGameOver() const
{
	return m_textures[GAMEOVER_P];
}

const Texture& Resources::getWIN() const
{
	return m_textures[WIN_P];
}

//--------------------------------------------------
const SoundBuffer& Resources::getEATMoneytune() const
{
	return m_soundefects[EatMoney_S];
}

const SoundBuffer& Resources::getGAMEOVERtune()const
{
	return m_soundefects[GameOver_S];
}

const SoundBuffer& Resources::getNEXTLEVELtune()const
{
	return m_soundefects[NextLevel_S];
}

const SoundBuffer& Resources::getGAMEMUSICtune()const
{
	return m_soundefects[GameMusic_S];
}

const SoundBuffer& Resources::getWINtune()const
{
	return m_soundefects[Win_S];
}

const SoundBuffer& Resources::getGIFTCOLLISONtune()const
{
	return m_soundefects[GiftColide_S];
}

const SoundBuffer& Resources::getFALLtune() const
{
	return m_soundefects[Fall_S];
}
const SoundBuffer& Resources::getDIGtune() const
{
	return m_soundefects[Dig_S];
}
const SoundBuffer& Resources::getRESETLEVELtune() const
{
	return m_soundefects[ResetLevel_S];
}












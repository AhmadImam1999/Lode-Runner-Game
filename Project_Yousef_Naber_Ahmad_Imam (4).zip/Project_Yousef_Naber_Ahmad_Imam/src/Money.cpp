#include "Money.h"
#include "Player.h"


Money::~Money()
{
}

void Money::collideWith(GameObject& other)
{
	other.collideWith(*this);
}

void Money::collideWith(Player& other)
{
	m_isDead = true;                           //to earase from vector 
	other.collideWith(*this);
}

void Money::collideWith(Enemy& other)
{

}

void Money::collideWith(Wall& other)
{

}

void Money::collideWith(Money& other)
{

}

void Money::collideWith(Rod& other)
{

}

void Money::collideWith(Ladder& other)
{

}
void Money::collideWith(AddLifeGift& other)
{

}
void Money::collideWith(AddScoreGift& other)
{

}
void Money::collideWith(AddTimeGift& other)
{

}
void Money::collideWith(AddEnemyGift& other)
{

}
void Money::collideWith(Gift& other)
{

}
char Money::c()
{
	return '+';
}

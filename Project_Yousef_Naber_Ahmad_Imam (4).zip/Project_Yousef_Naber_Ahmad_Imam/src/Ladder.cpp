#include "Ladder.h"
#include "Player.h"
#include <iostream>

Ladder::~Ladder()
{

}

void Ladder::collideWith(GameObject& other)
{
	other.collideWith(*this);
}

void Ladder::collideWith(Player& other)
{
	
	other.collideWith(*this);

}

void Ladder::collideWith(Enemy& other)
{
	
}

void Ladder::collideWith(Wall& other)
{

}

void Ladder::collideWith(Money& other)
{

}

void Ladder::collideWith(Rod& other)
{

}


void Ladder::collideWith(Ladder& other)
{

}
void Ladder::collideWith(AddLifeGift& other)
{

}
void Ladder::collideWith(AddScoreGift& other)
{

}
void Ladder::collideWith(AddTimeGift& other)
{

}
void Ladder::collideWith(AddEnemyGift& other)
{

}
void Ladder::collideWith(Gift& other)
{

}

char Ladder::c()
{
	return 'H';
}



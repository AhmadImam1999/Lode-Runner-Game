#include "AddTimeGift.h"
#include "Player.h"



AddTimeGift::~AddTimeGift()
{
}

void AddTimeGift::collideWith(GameObject& other)
{
	other.collideWith(*this);
}

void AddTimeGift::collideWith(Player& other)
{
	m_isDead = true;                           //to earase from vector 
	other.collideWith(*this);
}
void AddTimeGift::collideWith(Enemy& other)
{

}

void AddTimeGift::collideWith(Wall& other)
{

}

void AddTimeGift::collideWith(Money& other)
{

}

void AddTimeGift::collideWith(Rod& other)
{

}
void AddTimeGift::collideWith(Ladder& other)
{

}
void AddTimeGift::collideWith(AddLifeGift& other)
{

}
void AddTimeGift::collideWith(AddScoreGift& other)
{

}
void AddTimeGift::collideWith(AddTimeGift& other)
{

}
void AddTimeGift::collideWith(AddEnemyGift& other)
{

}
void AddTimeGift::collideWith(Gift& other)
{
	other.collideWith(*this);
}
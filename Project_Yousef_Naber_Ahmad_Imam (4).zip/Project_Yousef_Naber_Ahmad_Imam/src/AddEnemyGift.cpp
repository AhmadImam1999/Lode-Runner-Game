#include "AddEnemyGift.h"
#include "Player.h"


AddEnemyGift::~AddEnemyGift()
{
}

void AddEnemyGift::collideWith(GameObject& other)
{
	other.collideWith(*this);
}

void AddEnemyGift::collideWith(Player& other)
{
	m_isDead = true;                           //to earase from vector 
	other.collideWith(*this);
}
void AddEnemyGift::collideWith(Enemy& other)
{

}

void AddEnemyGift::collideWith(Wall& other)
{

}

void AddEnemyGift::collideWith(Money& other)
{

}

void AddEnemyGift::collideWith(Rod& other)
{

}

void AddEnemyGift::collideWith(Ladder& other)
{

}
void AddEnemyGift::collideWith(AddLifeGift& other)
{

}
void AddEnemyGift::collideWith(AddScoreGift& other)
{

}
void AddEnemyGift::collideWith(AddTimeGift& other)
{

}
void AddEnemyGift::collideWith(AddEnemyGift& other)
{

}
void AddEnemyGift::collideWith(Gift& other)
{
	other.collideWith(*this);
}
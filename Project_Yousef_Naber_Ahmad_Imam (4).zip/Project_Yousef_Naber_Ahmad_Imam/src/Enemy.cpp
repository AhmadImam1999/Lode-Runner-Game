#include "Enemy.h"
#include "Player.h"

#include <iostream>

Enemy::Enemy()
	:SelfMovment()
{
}

Enemy::Enemy(const sf::Texture& texture, const sf::Vector2f& pos, float size)
	: SelfMovment(texture, pos, size)
{

	m_shape.setTexture(&texture);
	m_shape.setSize(sf::Vector2f(size, size));
	m_shape.setPosition(pos);
	m_shape.setSize(sf::Vector2f(50, 50));
}

Enemy::~Enemy()
{
}

void Enemy::collideWith(GameObject& other)
{
	other.collideWith(*this);
}

void Enemy::collideWith(Player& other)
{

	other.collideWith(*this);

}

void Enemy::collideWith(Enemy& other)
{

	other.collideWith(*this);
}

void Enemy::collideWith(Wall& other)
{
	stop();
}

void Enemy::collideWith(Money& other)
{

}

void Enemy::collideWith(Rod& other)
{
	

}
void Enemy::collideWith(Ladder& other)
{

}
void Enemy::collideWith(AddLifeGift& other)
{

}
void Enemy::collideWith(AddScoreGift& other)
{

}
void Enemy::collideWith(AddTimeGift& other)
{

}
void Enemy::collideWith(AddEnemyGift& other)
{

}
void Enemy::collideWith(Gift& other)
{
	
}





Vector2f Enemy::setDirection(sf::Vector2f& direction, float time,int D)
{
	setRandomDirection(time);
	return m_direction;
}



void Enemy::setRandomDirection(float time)
{

	float  timeElaped = m_clock.getElapsedTime().asSeconds();



	if (timeElaped >= 1.5) {
		int direction = rand() % 4;

		switch (direction)
		{


		case UP:
			
			m_direction = sf::Vector2f({ 0,-m_Enemymovespeed * time });
			break;

		case DOWN:
			m_direction = sf::Vector2f({ 0,m_Enemymovespeed * time });
			break;

		case RIGHT:
			m_shape.setScale(1, 1);
			m_shape.setRotation(360);
			m_direction = sf::Vector2f({ m_Enemymovespeed * time,0 });
			break;

		case LEFT:
			m_shape.setScale(-1, 1);
			m_shape.setRotation(0);
			m_direction = sf::Vector2f({ -m_Enemymovespeed * time,0 });
			break;
		default:
			m_direction = sf::Vector2f(0, 0);
		}

		m_clock.restart();
	}



}
void Enemy::setConstant_Direction(float time)
{

	float  timeElaped = m_clock.getElapsedTime().asSeconds();



	if (timeElaped > 1.5) {
		int direction =2+ rand() % 2;

		switch (direction)
		{
		case RIGHT:
			m_shape.setScale(1, 1);
			m_shape.setRotation(360);
			m_direction = sf::Vector2f({ m_Enemymovespeed * time,0 });
			break;

		case LEFT:
			m_shape.setScale(-1, 1);
			m_shape.setRotation(0);
			m_direction = sf::Vector2f({ -m_Enemymovespeed * time,0 });
			break;
		default:
			m_direction = sf::Vector2f(0, 0);
		}

		m_clock.restart();
	}
	
}







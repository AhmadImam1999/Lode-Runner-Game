#include "Wall.h"
#include "Player.h"
#include "Enemy.h"
#include <iostream>

Wall::~Wall()
{

}

void Wall::collideWith(GameObject& other)
{
	other.collideWith(*this);
}

void Wall::collideWith(Player& other)
{

	other.collideWith(*this);

}

void Wall::collideWith(Enemy& other)
{
	other.collideWith(*this);

}

void Wall::collideWith(Wall& other)
{

}

void Wall::collideWith(Money& other)
{

}

void Wall::collideWith(Rod& other)
{

}
void Wall::collideWith(Ladder& other)
{

}
void Wall::collideWith(AddLifeGift& other)
{

}
void Wall::collideWith(AddScoreGift& other)
{

}
void Wall::collideWith(AddTimeGift& other)
{

}
void Wall::collideWith(AddEnemyGift& other)
{

}
void Wall::collideWith(Gift& other)
{

}

char Wall::c()
{
	return '#';
}
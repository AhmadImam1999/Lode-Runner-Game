#include "SelfMovment.h"
#include <iostream>

using std::cout;
using std::endl;

SelfMovment::SelfMovment():GameObject()
{

}

SelfMovment::SelfMovment(const sf::Texture& texture, const sf::Vector2f& pos, float size)
	: GameObject(texture, pos, size)
{
	m_shape.setTexture(&texture);
	m_shape.setSize(sf::Vector2f(size, size));
	m_shape.setPosition(pos);
	m_shape.setOrigin(m_shape.getSize().x / 2, m_shape.getSize().y / 2);

}

SelfMovment::~SelfMovment()
{
}

void SelfMovment::inishialPos()
{
	m_shape.setPosition(m_inishialPosition);
}




void SelfMovment::move(sf::Vector2f direction, float time,int D)
{


	m_direction = setDirection(direction, time, D);
	m_shape.move(m_direction);

	if (!isinbound())
	{
		stop();
	}
}

void SelfMovment::stop()
{
	m_shape.move(-m_direction);
}

bool SelfMovment::isinbound()
{
	if (m_shape.getPosition().x  < 0 ||
		m_shape.getPosition().x > width - TILE_SIZE ||
		m_shape.getPosition().y + 3 * TILE_SIZE < 0 ||
		m_shape.getPosition().y  > height - 2 * TILE_SIZE)
		return false;

	return true;
}








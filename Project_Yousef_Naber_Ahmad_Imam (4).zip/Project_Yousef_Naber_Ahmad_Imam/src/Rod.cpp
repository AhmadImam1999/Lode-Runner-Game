#include "Rod.h"
#include "Player.h"
#include <iostream>

Rod::~Rod()
{

}

void Rod::collideWith(GameObject& other)
{
	other.collideWith(*this);
}

void Rod::collideWith(Player& other)
{

	other.collideWith(*this);

}

void Rod::collideWith(Enemy& other)
{

}

void Rod::collideWith(Wall& other)
{

}

void Rod::collideWith(Money& other)
{

}

void Rod::collideWith(Rod& other)
{

}
void Rod::collideWith(Ladder& other)
{

}
void Rod::collideWith(AddLifeGift& other)
{

}
void Rod::collideWith(AddScoreGift& other)
{

}
void Rod::collideWith(AddTimeGift& other)
{

}
void Rod::collideWith(AddEnemyGift& other)
{

}
void Rod::collideWith(Gift& other)
{

}

char Rod::c()
{
	return '-';
}
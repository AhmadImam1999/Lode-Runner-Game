
#include "GameObject.h"

GameObject::GameObject()
{

}

GameObject::GameObject(const Texture& texture, const Vector2f position, const float size)
	:m_isDead(false)
{
	m_shape.setTexture(&texture);
	m_shape.setSize(sf::Vector2f(size, size));
	m_shape.setPosition(position);
	m_shape.setScale(1, 1);
}

GameObject::~GameObject()
{
}

const Vector2f& GameObject::getposition() const
{
	return m_shape.getPosition();
}

Vector2f GameObject::getSize() const
{
	return m_shape.getSize();
}

void GameObject::draw(RenderWindow& window)
{
	window.draw(m_shape);
}

FloatRect GameObject::getGlobalBound() const
{
	return m_shape.getGlobalBounds();
}

bool GameObject::isDead() const
{
	return m_isDead;
}


void GameObject::setposition(Vector2f pos)
{
	m_shape.setPosition(pos);
}

#pragma once
#include "GameObject.h"

enum Direction
{
	UP,
	DOWN,
	RIGHT,
	LEFT,
	STOP       
};
class SelfMovment : public GameObject
{
public:
	SelfMovment();//constrcture
	SelfMovment(const sf::Texture& texture,const sf::Vector2f& pos,float size);
	virtual ~SelfMovment();//desstrcture

	//-------moving---------------
	virtual void move(sf::Vector2f direction, float time,int D);   //move object to wanted direction 
	virtual void stop();						//move to -(direction) make object stop
	bool isinbound();							//check if in window bound
	virtual Vector2f setDirection(sf::Vector2f& direction,float time, int D) = 0;//set the irection

	void inishialPos();//inishal pos for reset level


protected:
	sf::Vector2f m_direction;
	Vector2f m_inishialPosition;
};
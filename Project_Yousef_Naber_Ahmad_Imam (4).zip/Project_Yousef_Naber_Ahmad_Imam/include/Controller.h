#pragma once

#include "Resources.h"
#include "Menu.h"
#include "Player.h"
#include "Enemy.h"
#include "Money.h"
#include "Rod.h"
#include "Ladder.h"
#include "Wall.h"
#include "AddScoreGift.h"
#include "AddEnemyGift.h"
#include "AddLifeGift.h"
#include "AddTimeGift.h"
#include"Setting.h"
#include"TowardPlayerEnemy.h"
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <thread>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>


using namespace std::chrono_literals;
enum SHAPE_CHAR
{
	PLAYER = '@',
	ENEMY = '%',
	WALL = '#',
	ROD = '-',
	LADDER = 'H',
	MONEY = '*',
	GIFT = '+'
};
class Controller
{

public:

	
	Controller();						  	  //open file
	~Controller();	//close file
	Vector2f Fall(Vector2f pos);
	int check(Vector2f D);
	//-------------------load-------------------
	bool openfile();
	void settoolbar();
	void clearObjects();                       //using vector.clear
	bool loadmatrix();                        //load level to matrix of char
	void loadlevel();						  //now can load same level from matrix of chars number of times needed	


	//------------------- game--------------
	void run();                                //run game
	void movechareters();
	void handelcolision();

	//----------------level events------------
	bool levelcomplited();                        //load next level
	void computeFinish();					      //end game

	//draw
	void draw();
	void drawBoard();
	void drawPlayer();
	void drawshapes();
	void drawEnemy();
	void drawtoolboar();

	//window clear & display
	void displaywindow();
	void clearwindow();
	void cratewindow();


	//--------------reset level------------------------
	void resertlevel();
	void resetscore();

private:
	//======= file =========
	std::fstream m_file;
	int m_col;
	int m_row;
	std::vector<std::vector<char>>  m_matrix;

	//====window 
	sf::RenderWindow m_window;
	sf::Clock m_clock;                //clock for mooving
	float m_time;
	float m_levelTime;
	sf::Clock m_timer;               //clock for level timer
	float timer;
	//-------   toolbar --------------
	sf::Text m_scoreToolbar;
	std::ostringstream m_scoreString;
	//========  objects =========
	std::unique_ptr <Player> m_player;    
	std::vector<std::unique_ptr<SelfMovment>> m_Enemy;   
	int m_enemyidx;
	std::vector<std::unique_ptr <NonSelfMovment>> m_boardPtr;
	//=====   score   ==============
	int m_MoneyAmount;
	int m_level;
	int m_currentLife;
	int m_currentScore;
	int m_currentMoney;

	//=====  massage pictures ============
	sf::RectangleShape m_background;
	sf::RectangleShape m_LevelComplited;
	sf::RectangleShape m_GameOver;
	sf::RectangleShape m_YouWin;
	sf::RectangleShape m_shape2;
	//====== music ================
	sf::Sound m_soundefect;
	sf::Music m_music;

};
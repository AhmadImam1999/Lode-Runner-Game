#pragma once

#include "Setting.h"
#include <fstream>
#include <sstream>
#include<iostream>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>


using std::cout;
using std::endl;
using sf::Font;
using sf::Texture;
using std::ifstream;
using std::vector;
using std::ostringstream;
using sf::SoundBuffer;

class Resources
{
public:
	//----------d-tor-------------------------
	~Resources();
	static Resources& instance();

	//----------get functions-----------------


	//----------get font----------------------
	const Font& getfont() const;

	const Texture& getBackround() const;
	const Texture& getMenu() const;
	const Texture& getPlayer() const;
	const Texture& getEnemy1() const;
	const Texture& getEnemy2() const;
	const Texture& getEnemy3() const;
	const Texture& getWall() const;
	const Texture& getGift() const;
	const Texture& getGift2() const;
	const Texture& getGift3() const;
	const Texture& getGift4() const;
	const Texture& getMoney() const;
	const Texture& getRod() const;
	const Texture& getLadder() const;
	const Texture& getGameOver() const;
	const Texture& getWIN() const;
	const Texture& getHelp() const;



	const SoundBuffer& getEATMoneytune()const;
	const SoundBuffer& getGAMEOVERtune()const;
	const SoundBuffer& getNEXTLEVELtune()const;
	const SoundBuffer& getGAMEMUSICtune()const;
	const SoundBuffer& getWINtune()const;
	const SoundBuffer& getGIFTCOLLISONtune()const;
	const SoundBuffer& getFALLtune()const;
	const SoundBuffer& getDIGtune()const;
	const SoundBuffer& getRESETLEVELtune()const;

	void loadresources();
	void loadsound();
	void loadtextures();
	void loadfont();

private:
	Resources();
	Resources(const Resources&) = default;
	Resources& operator= (const Resources&) = default;


	//-----------load functions---------------

	//----------load font---------------------

	vector<sf::Texture> m_textures;		               //game figures textures
	sf::Font m_font;                                  //font for the text messeges
	ostringstream m_scoreToolbar;                   //string for toolbar text massages
	std::vector<sf::SoundBuffer> m_soundefects;
};









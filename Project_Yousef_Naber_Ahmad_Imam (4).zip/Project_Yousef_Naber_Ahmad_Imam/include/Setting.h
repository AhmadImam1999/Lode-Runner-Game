#pragma once

#include <string>
using std::string;

enum PICTURE
{
	PLAYER_P,
	ENEMY1_P,
	ENEMY2_P,
	ENEMY3_P,
	GIFT_P,
	GIFT2_P,
	GIFT3_P,
	GIFT4_P,
	MONEY_P,
	WALL_P,
	ROD_P,
	LADDER_P,
	BACKGROUND_P,
	MENU_P,
	GAMEOVER_P,
	HELP_P,
	WIN_P
};


enum SOUNDEFECTS
{
	ENEMYcolide_S,
	GameOver_S,
	NextLevel_S,
	EatMoney_S,
	GameMusic_S,
	MenuMusic_S,
	Win_S,
	GiftColide_S,
	ResetLevel_S,
	Fall_S,
	Dig_S
};



const int TILE_SIZE = 45;
const string FILE_NAME = "Board.txt";

const int width = 910;
const int height = 910;

const float m_movespeed = 25;
const float m_Enemymovespeed = 20;





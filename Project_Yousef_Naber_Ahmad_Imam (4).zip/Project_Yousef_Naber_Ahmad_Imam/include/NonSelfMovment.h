#pragma once
#include "GameObject.h"
#include<SFML/Graphics.hpp>

using sf::Texture;
using sf::Vector2f;


class NonSelfMovment : public GameObject
{
public:
	using GameObject::GameObject;
	virtual char c()=0;
	virtual ~NonSelfMovment();
};
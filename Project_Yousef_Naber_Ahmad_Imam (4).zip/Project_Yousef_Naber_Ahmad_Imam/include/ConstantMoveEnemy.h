#pragma once
#include "Enemy.h"

class ConstantMoveEnemy :public Enemy
{
public:

	ConstantMoveEnemy();
	ConstantMoveEnemy(const sf::Texture& texture, const sf::Vector2f& pos, float size);
	virtual ~ConstantMoveEnemy();

	virtual Vector2f setDirection(sf::Vector2f& direction, float time,int D)override;
	 Vector2f set_consDirection(sf::Vector2f& direction, float time);
	
private:



};
